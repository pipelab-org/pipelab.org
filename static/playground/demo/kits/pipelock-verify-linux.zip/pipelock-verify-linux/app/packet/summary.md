# Blocked: secret exfiltration in a request body

- **Category:** Secret exfiltration
- **Bench case:** `url-dlp-aws-key-001`
- **Transport:** forward
- **Destination:** attacker-controlled collector (reserved example host)
- **Decision:** block
- **Receipts:** 2 (chain verifies)

## Without Pipelock

A bare agent posts a credential-shaped value to a collector and the value escapes.

## With Pipelock

Pipelock scans the request body, detects the credential-shaped value, blocks the request, and signs a receipt recording the block.

These receipts record the *mediated decisions* Pipelock signed. A verified chain proves those decisions were signed and untampered; it does not prove session completeness or that no event was missed.
