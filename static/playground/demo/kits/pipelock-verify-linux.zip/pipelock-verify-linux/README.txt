Pipelock - verify the signed run (Linux)

Run:  ./verify.sh
Shows "result: VALID" if every signature and binding checks out against
Pipelock's published key. Nothing here touches the internet.
