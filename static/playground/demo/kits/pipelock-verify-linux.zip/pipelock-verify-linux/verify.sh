#!/bin/bash
cd "$(dirname "$0")/app"
echo "Verifying the signed Pipelock run offline, against the published key..."
chmod +x ./pipelock-verifier
./pipelock-verifier verify-run pipelock-session
