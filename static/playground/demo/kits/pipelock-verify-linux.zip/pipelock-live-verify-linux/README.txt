Pipelock - verify your live session (Linux)

Open a terminal in this folder and run:

  ./verify.sh

Double-clicking usually opens it in a text editor instead of running it - that is normal on Linux; use the terminal.
A valid run prints result: VALID. Nothing here touches the internet.
