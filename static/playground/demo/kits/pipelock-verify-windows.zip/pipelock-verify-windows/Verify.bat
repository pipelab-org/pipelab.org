@echo off
cd /d "%~dp0app"
echo Verifying the signed Pipelock audit packet, offline...
echo.
pipelock-verifier.exe audit-packet packet --key 65c1e83850fe24c986f44bdd3a95360602d2f4f198f1c95e2d500d2b9495aaaf
echo.
echo result: VALID means every signature and the hash chain held. No network was used.
echo.
pause
