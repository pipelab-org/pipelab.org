Pipelock - verify the signed run (Windows)

Double-click verify.bat. Shows "result: VALID" against Pipelocks published key.
Windows SmartScreen may warn on the unsigned download: click More info -> Run anyway.
