@echo off
cd /d "%~dp0app"
echo Verifying the signed Pipelock run offline, against the published key...
pipelock-verifier.exe verify-run pipelock-session
pause
