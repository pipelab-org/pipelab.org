Pipelock - verify your live session (Windows)

Double-click Verify.bat.
A valid run prints result: VALID. Nothing here touches the internet.
