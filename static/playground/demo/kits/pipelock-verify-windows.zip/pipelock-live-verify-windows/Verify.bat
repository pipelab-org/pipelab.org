@echo off
cd /d "%~dp0app" || exit /b 1
echo Verifying the full Pipelock playground trust chain, offline...
echo.
pipelock-verifier.exe verify-run run --orchestrator-key 99f16ec99b3f55180f75a025affa6a9cced3e559a38590fa6cac48a736221a2c --archive
set "verify_status=%errorlevel%"
echo.
if "%verify_status%"=="0" (echo result: VALID means every signature, the receipt chain, witnesses, and run binding held.) else (echo Verification FAILED: the trust chain did not hold. Do not trust this run.)
echo No network was used.
echo.
pause
exit /b %verify_status%
