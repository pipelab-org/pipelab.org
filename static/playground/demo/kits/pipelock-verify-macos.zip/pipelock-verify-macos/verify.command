#!/bin/bash
cd "$(dirname "$0")/app"
if [ "$(uname -m)" = "arm64" ]; then BIN=./pipelock-verifier-arm64; else BIN=./pipelock-verifier-amd64; fi
chmod +x "$BIN"
echo "Verifying the signed Pipelock run offline, against the published key..."
"$BIN" verify-run pipelock-session
