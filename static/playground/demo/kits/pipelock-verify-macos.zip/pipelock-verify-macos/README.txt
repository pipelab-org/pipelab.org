Pipelock - verify the signed run (macOS)

Double-click verify.command (or run it in Terminal).
Shows "result: VALID" against Pipelock's published key. Nothing touches the internet.
Note: macOS may warn that the verifier is from an unidentified developer (it is an
unsigned download). Right-click the verify.command -> Open, or allow it in
System Settings -> Privacy & Security, then run again.
