#!/bin/bash
cd "$(dirname "$0")/app" || exit 1
echo "Verifying the full Pipelock playground trust chain, offline..."
echo
./pipelock-verifier verify-run run --orchestrator-key 99f16ec99b3f55180f75a025affa6a9cced3e559a38590fa6cac48a736221a2c --archive
verify_status=$?
echo
echo "result: VALID means every signature, the receipt chain, witnesses, and run binding held."
echo "No network was used."
read -n 1 -s -r -p "Press any key to close."
exit "$verify_status"
