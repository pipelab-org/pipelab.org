Pipelock - verify your live session (macOS)

The verifier is a universal Intel/Apple Silicon binary, but it is not Apple-notarized, so macOS Gatekeeper may block a freshly downloaded copy. If double-clicking Verify.command is blocked, open Terminal in this folder and run:

  xattr -d com.apple.quarantine Verify.command app/pipelock-verifier
  ./Verify.command

A valid run prints result: VALID. Nothing here touches the internet. Notarized macOS support is planned; Linux and Windows need no extra step.
